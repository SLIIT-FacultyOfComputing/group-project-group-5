package com.example.Backend.model;

public enum Role {
    TRAINER,
    RECEPTIONIST,
    CLEANING_STAFF,
    MANAGER,

}
