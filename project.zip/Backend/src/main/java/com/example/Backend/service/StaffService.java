package com.example.Backend.service;

import com.example.Backend.model.Role;
import com.example.Backend.model.Staff;
import com.example.Backend.repository.StaffRepository;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StaffService {

    @Autowired
    private StaffRepository staffRepository;

    public Staff addStaff(Staff staff) {
        String hashed = BCrypt.hashpw(staff.getPassword(), BCrypt.gensalt());
        staff.setPassword(hashed);
        return staffRepository.save(staff);
    }

    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    public Optional<Staff> getStaffByNIC(String NIC) {
        return staffRepository.findById(NIC);
    }

    public List<Staff> searchByName(String name) {
        return staffRepository.findByNameContainingIgnoreCase(name);
    }

    public void deleteStaff(String NIC) {
        staffRepository.deleteById(NIC);
    }

    public Staff updateNIC (String NIC, String newNIC) {
        Staff staff = staffRepository.findById(NIC).orElseThrow(() -> new RuntimeException("Staff not found"));
        staff.setNIC(newNIC);
        return staffRepository.save(staff);
    }

    public  Staff updatePassword(String NIC, String newPassword) {
        Staff staff = staffRepository.findById(NIC).orElse(null);
        if (staff != null) {
            String hashed = BCrypt.hashpw(newPassword, BCrypt.gensalt());
            staff.setPassword(hashed);
            return staffRepository.save(staff);
        } else {
            return null;
        }
    }

    public Staff updateName(String NIC, String newName) {
        Staff staff = staffRepository.findById(NIC).orElse(null);
        if (staff != null) {
            staff.setName(newName);
            return staffRepository.save(staff);
        } else {
            return null;
        }
    }

    public Staff updatePhone(String NIC, String newPhone) {
        Staff staff = staffRepository.findById(NIC).orElse(null);
        if (staff != null) {
            staff.setPhone(newPhone);
            return staffRepository.save(staff);
        }else {
            return null;
        }
    }

    public Staff updateShift(String NIC, String newShift) {
        Staff staff = staffRepository.findById(NIC).orElse(null);
        if (staff != null) {
            staff.setShift(newShift);
            return staffRepository.save(staff);
        } else {
            return null;
        }
    }

    public Staff updateRole(String NIC, String newRole) {
        Optional<Staff> staff = staffRepository.findById(NIC);
        if (staff.isPresent()) {
            Staff staff1 = staff.get();
            Role role = Role.valueOf(newRole.toUpperCase());
            staff1.setRole(role);
            return staffRepository.save(staff1);
        } else {
            return null;
        }
    }
}