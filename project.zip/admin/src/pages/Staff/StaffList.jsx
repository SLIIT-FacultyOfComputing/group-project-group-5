import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getStaff, deleteStaff, searchStaffByName } from "../../services/api";

const StaffList = () => {
  const [staff, setStaff] = useState([]);
  const [displayStaff, setDisplayStaff] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState(null);

  useEffect(() => {
    const fetchStaff = async () => {
      try {
        setLoading(true);
        const response = await getStaff();
        setStaff(response.data);
        setDisplayStaff(response.data);
      } catch (error) {
        setError("Failed to fetch staff");
        console.error("Error fetching staff:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchStaff();
  }, []);

  const handleSearch = async () => {
    if (!search.trim()) {
      setDisplayStaff(staff);
      return;
    }

    try {
      setLoading(true);
      const response = await searchStaffByName(search);
      setDisplayStaff(response.data.length > 0 ? response.data : staff);
    } catch (error) {
      setError("Error searching staff");
      console.error("Error searching staff:", error);
    } finally {
      setLoading(false);
    }
  };

  const openDeleteModal = (id) => {
    setSelectedStaffId(id);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedStaffId) {
      setError("No staff member selected for deletion");
      setIsDeleteModalOpen(false);
      return;
    }

    try {
      setLoading(true);
      await deleteStaff(selectedStaffId);
      
      // Update arrays regardless of response format - this is the key fix
      // Filter both arrays to remove the selected staff member
      setStaff(prevStaff => prevStaff.filter(member => member.id !== selectedStaffId));
      setDisplayStaff(prevDisplay => prevDisplay.filter(member => member.id !== selectedStaffId));
      
      // Close modal after successful deletion
      setIsDeleteModalOpen(false);
      
    } catch (error) {
      console.error("Error deleting staff:", error);
      setError("Failed to delete staff member. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
            <div className="bg-gradient-to-r from-rose-700 to-rose-500 p-6 flex flex-col sm:flex-row justify-between items-center">
              <div className="flex items-center mb-4 sm:mb-0">
                <div className="bg-white bg-opacity-30 p-2 rounded-lg mr-3 shadow-inner">
                  <svg className="w-6 h-6 text-red" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                  </svg>
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white drop-shadow-sm">
                  Staff Overview
                </h1>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex items-center bg-white bg-opacity-10 backdrop-blur-sm px-4 py-2 rounded-lg border border-white border-opacity-20">
                  <svg className="w-5 h-5 text-red opacity-80 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z"></path>
                  </svg>
                  <span className="text-red font-medium">Total: {staff.length} members</span>
                </div>
                <Link
                  to="/add-staff"
                  className="flex items-center bg-white text-rose-600 px-4 py-2 rounded-lg border border-white shadow-sm hover:bg-opacity-90 transition-all duration-200"
                >
                  <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                  </svg>
                  <span className="font-medium">Add Staff</span>
                </Link>
              </div>
            </div>

            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center">
                <input
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="Search by Name"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
                <button
                    className="ml-2 px-4 py-2 bg-rose-600 text-white rounded-lg"
                    onClick={handleSearch}
                >
                  Search
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-700">
                <thead className="text-xs text-white uppercase bg-rose-600">
                <tr>
                  <th className="px-6 py-4">ID</th>
                  <th className="px-6 py-4">Name</th>
                  <th className="px-6 py-4">NIC</th>
                  <th className="px-6 py-4">Role</th>
                  <th className="px-6 py-4">Phone</th>
                  <th className="px-6 py-4">Shift</th>
                  <th className="px-6 py-4">Start Date</th>
                  <th className="px-6 py-4">Actions</th>
                </tr>
                </thead>
                <tbody>
                {loading ? (
                    <tr>
                      <td colSpan="8" className="text-center py-4">Loading...</td>
                    </tr>
                ) : displayStaff.length > 0 ? (
                    displayStaff.map((member) => (
                        <tr key={member.id} className="border-b">
                          <td className="px-6 py-4">{member.id}</td>
                          <td className="px-6 py-4">{member.name}</td>
                          <td className="px-6 py-4">{member.nic}</td>
                          <td className="px-6 py-4">{member.role}</td>
                          <td className="px-6 py-4">{member.phone || "N/A"}</td>
                          <td className="px-6 py-4">{member.shift || "N/A"}</td>
                          <td className="px-6 py-4">{member.startDate}</td>
                          <td className="px-6 py-4">
                            <button
                                className="px-4 py-2 bg-rose-600 text-white rounded-lg"
                                onClick={() => openDeleteModal(member.id)}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                    ))
                ) : (
                    <tr>
                      <td colSpan="8" className="text-center py-4">No staff found</td>
                    </tr>
                )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {isDeleteModalOpen && (
            <div className="fixed inset-0 bg-rose-600 bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full">
                <h2 className="text-lg font-bold mb-4 text-gray-800">Confirm Deletion</h2>
                <p className="text-gray-600 mb-6">
                  Are you sure you want to delete this staff member? This action cannot be undone.
                </p>
                <div className="mt-4 flex justify-end space-x-3">
                  <button
                      className="px-4 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400 transition-colors"
                      onClick={() => setIsDeleteModalOpen(false)}
                      disabled={loading}
                  >
                    Cancel
                  </button>
                  <button
                      className="px-4 py-2 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors flex items-center"
                      onClick={handleDelete}
                      disabled={loading}
                  >
                    {loading ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Deleting...
                        </>
                    ) : "Delete"}
                  </button>
                </div>
              </div>
            </div>
        )}
      </div>
  );
};

export default StaffList;