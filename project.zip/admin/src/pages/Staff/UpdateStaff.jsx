import { useState, useEffect } from "react";
import { getStaffById, updateStaff } from "../../services/api";
import { useParams, useNavigate } from "react-router-dom";

const UpdateStaff = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    nic: "",
    role: "",
    phone: "",
    shift: "",
    startDate: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    const fetchStaffDetails = async () => {
      try {
        setLoading(true);
        const response = await getStaffById(id);
        
        // Format date from backend to frontend format if needed
        const staffData = response.data;
        if (staffData.startDate) {
          staffData.startDate = formatDateForInput(staffData.startDate);
        }
        
        setFormData(staffData);
      } catch (error) {
        console.error("Error fetching staff details:", error);
        setError("Failed to load staff details.");
      } finally {
        setLoading(false);
      }
    };

    fetchStaffDetails();
  }, [id]);

  // Format date from yyyy-MM-dd to yyyy-MM-dd (for input type="date")
  const formatDateForInput = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  };

  const validateForm = () => {
    const errors = {};
    
    // Name validation (required)
    if (!formData.name.trim()) {
      errors.name = "Name is required";
    }
    
    // NIC validation - assumes format like 123456789V
    if (!formData.nic.trim()) {
      errors.nic = "NIC is required";
    } else if (!/^\d{9}[vVxX]$|^\d{12}$/.test(formData.nic)) {
      errors.nic = "Invalid NIC format";
    }
    
    // Role validation (required)
    if (!formData.role.trim()) {
      errors.role = "Role is required";
    }
    
    // Phone validation (optional but should be valid if provided)
    if (formData.phone && !/^\d{10}$/.test(formData.phone.replace(/\s/g, ''))) {
      errors.phone = "Phone number should be 10 digits";
    }
    
    // Date validation (must be past or present)
    if (!formData.startDate) {
      errors.startDate = "Start date is required";
    } else {
      const selectedDate = new Date(formData.startDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate > today) {
        errors.startDate = "Start date cannot be in the future";
      }
    }
    
    // Email validation (optional but should be valid if provided)
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Invalid email format";
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    
    // Clear validation error when field is edited
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);
    
    // Validate form before submission
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);

    try {
      await updateStaff(id, formData);
      setSuccess(true);
      setTimeout(() => navigate("/staff-list"), 2000); // Redirect after success
    } catch (error) {
      console.error("Error updating staff:", error);
      if (error.response && error.response.data) {
        setError(`Failed to update staff: ${error.response.data.message || 'Server validation failed'}`);
      } else {
        setError("Failed to update staff. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen py-6 sm:py-8 md:py-12">
      <div className="container mx-auto px-4 sm:px-6 max-w-full sm:max-w-3xl">
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg sm:shadow-xl overflow-hidden border border-gray-100">
          <div className="bg-gradient-to-r from-rose-700 to-rose-500 p-5 sm:p-6 md:p-8 relative">
            <div className="relative">
              <h1 className="text-xl sm:text-2xl font-bold text-white drop-shadow-sm">
                Update Staff Member
              </h1>
              <p className="text-rose-100 text-sm sm:text-base font-normal mb-2 sm:mb-3 drop-shadow-sm">
                Modify the details of the staff member below.
              </p>
            </div>
          </div>

          <div className="p-5 sm:p-6 md:p-8">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-3 sm:p-4 rounded-lg sm:rounded-xl mb-4 sm:mb-6">
                <h3 className="font-medium">Error</h3>
                <p className="text-xs sm:text-sm text-rose-600">{error}</p>
              </div>
            )}

            {success && (
              <div className="bg-green-50 border border-green-200 text-green-700 p-3 sm:p-4 rounded-lg sm:rounded-xl mb-4 sm:mb-6">
                <h3 className="font-medium">Success</h3>
                <p className="text-xs sm:text-sm text-green-600">
                  Staff member updated successfully!
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6 sm:space-y-8">
              <div className="space-y-4 sm:space-y-5">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    className={`w-full border ${validationErrors.name ? 'border-rose-500' : 'border-gray-300'} rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500`}
                    value={formData.name}
                    onChange={handleChange}
                    required
                    disabled={loading}
                  />
                  {validationErrors.name && (
                    <p className="mt-1 text-xs text-rose-500">{validationErrors.name}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="nic" className="block text-sm font-medium text-gray-700">
                    NIC <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="nic"
                    name="nic"
                    type="text"
                    className={`w-full border ${validationErrors.nic ? 'border-rose-500' : 'border-gray-300'} rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500`}
                    value={formData.nic}
                    onChange={handleChange}
                    required
                    disabled={loading}
                    placeholder="123456789V or 123456789012"
                  />
                  {validationErrors.nic && (
                    <p className="mt-1 text-xs text-rose-500">{validationErrors.nic}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                    Role <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="role"
                    name="role"
                    type="text"
                    className={`w-full border ${validationErrors.role ? 'border-rose-500' : 'border-gray-300'} rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500`}
                    value={formData.role}
                    onChange={handleChange}
                    required
                    disabled={loading}
                  />
                  {validationErrors.role && (
                    <p className="mt-1 text-xs text-rose-500">{validationErrors.role}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    Phone
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="text"
                    className={`w-full border ${validationErrors.phone ? 'border-rose-500' : 'border-gray-300'} rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500`}
                    value={formData.phone}
                    onChange={handleChange}
                    disabled={loading}
                    placeholder="0771234567"
                  />
                  {validationErrors.phone && (
                    <p className="mt-1 text-xs text-rose-500">{validationErrors.phone}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="shift" className="block text-sm font-medium text-gray-700">
                    Shift (Optional)
                  </label>
                  <input
                    id="shift"
                    name="shift"
                    type="text"
                    className="w-full border-gray-300 rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500"
                    value={formData.shift}
                    onChange={handleChange}
                    disabled={loading}
                  />
                </div>

                <div>
                  <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">
                    Start Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="startDate"
                    name="startDate"
                    type="date"
                    max={new Date().toISOString().split('T')[0]} // Restrict to today or earlier
                    className={`w-full border ${validationErrors.startDate ? 'border-rose-500' : 'border-gray-300'} rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500`}
                    value={formData.startDate}
                    onChange={handleChange}
                    required
                    disabled={loading}
                  />
                  {validationErrors.startDate && (
                    <p className="mt-1 text-xs text-rose-500">{validationErrors.startDate}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    className={`w-full border ${validationErrors.email ? 'border-rose-500' : 'border-gray-300'} rounded-lg shadow-sm focus:ring-rose-500 focus:border-rose-500`}
                    value={formData.email}
                    onChange={handleChange}
                    disabled={loading}
                  />
                  {validationErrors.email && (
                    <p className="mt-1 text-xs text-rose-500">{validationErrors.email}</p>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-rose-700 to-rose-500 text-white font-medium rounded-lg shadow-lg hover:from-rose-800 hover:to-rose-600 focus:ring-2 focus:ring-rose-300 focus:ring-offset-2"
                disabled={loading}
              >
                {loading ? "Updating..." : "Update Staff"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateStaff;