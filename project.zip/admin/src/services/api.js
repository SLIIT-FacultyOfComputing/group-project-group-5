import axios from "axios";

const BASE_URL = "http://localhost:8090";

// Staff APIs
export const addStaff = async (staff) => {
  return axios.post(`${BASE_URL}/api/staff`, staff);
};

export const getStaff = async () => {
  return axios.get(`${BASE_URL}/api/staff`);
};

export const getStaffById = async (id) => {
  return axios.get(`${BASE_URL}/api/staff/${id}`);
};

export const updateStaff = async (id, staff) => {
  return axios.put(`${BASE_URL}/api/staff/${id}`, staff);
};

export const deleteStaff = async (id) => {
  return axios.delete(`${BASE_URL}/api/staff/${id}`);
};

export const searchStaffByName = async (name) => {
  return axios.get(`${BASE_URL}/api/staff/search?name=${name}`);
};